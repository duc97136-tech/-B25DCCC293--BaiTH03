import { Link } from "react-router-dom";
import { useAppDispatch } from "../app/hooks";
import { addToCart } from "../features/cart/cartSlice";
import type { Product } from "../types";
import { formatPrice } from "../utils/format";

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const dispatch = useAppDispatch();

  return (
    <div className="flex flex-col overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm transition hover:shadow-md dark:border-slate-700 dark:bg-slate-800">
      <Link to={`/products/${product.id}`} className="flex h-48 items-center justify-center bg-white p-4">
        <img src={product.image} alt={product.title} className="h-full object-contain" loading="lazy" />
      </Link>
      <div className="flex flex-1 flex-col gap-2 p-4">
        <span className="text-xs uppercase tracking-wide text-slate-500 dark:text-slate-400">
          {product.category}
        </span>
        <Link
          to={`/products/${product.id}`}
          className="line-clamp-2 font-semibold text-slate-900 hover:text-emerald-600 dark:text-slate-100 dark:hover:text-emerald-400"
        >
          {product.title}
        </Link>
        <div className="mt-auto flex items-center justify-between pt-2">
          <span className="text-lg font-bold text-emerald-600 dark:text-emerald-400">
            {formatPrice(product.price)}
          </span>
          <button
            onClick={() => dispatch(addToCart(product))}
            className="rounded-lg bg-emerald-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-emerald-700"
          >
            Thêm vào giỏ
          </button>
        </div>
      </div>
    </div>
  );
}
