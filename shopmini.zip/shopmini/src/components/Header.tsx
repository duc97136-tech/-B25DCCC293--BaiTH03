import { Link, useNavigate } from "react-router-dom";
import { useAppSelector } from "../app/hooks";
import { selectCartCount } from "../features/cart/cartSlice";
import { useAuth } from "../contexts/AuthContext";
import { useTheme } from "../contexts/ThemeContext";

export default function Header() {
  const cartCount = useAppSelector(selectCartCount);
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  return (
    <header className="sticky top-0 z-10 border-b border-slate-200 bg-white/90 backdrop-blur dark:border-slate-700 dark:bg-slate-900/90">
      <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-3">
        <Link to="/" className="text-xl font-bold text-emerald-600 dark:text-emerald-400">
          🛍️ ShopMini
        </Link>

        <nav className="flex flex-wrap items-center gap-2 text-sm sm:gap-3">
          <Link
            to="/cart"
            className="relative rounded-lg px-3 py-1.5 font-medium text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800"
          >
            🛒 Giỏ hàng
            <span className="ml-1.5 inline-flex min-w-5 items-center justify-center rounded-full bg-emerald-600 px-1.5 text-xs font-semibold text-white">
              {cartCount}
            </span>
          </Link>

          {user ? (
            <>
              <span className="text-slate-600 dark:text-slate-300">
                Xin chào, <strong>{user.username}</strong>
              </span>
              <button
                onClick={handleLogout}
                className="rounded-lg border border-slate-300 px-3 py-1.5 font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-600 dark:text-slate-200 dark:hover:bg-slate-800"
              >
                Đăng xuất
              </button>
            </>
          ) : (
            <Link
              to="/login"
              className="rounded-lg bg-emerald-600 px-3 py-1.5 font-medium text-white hover:bg-emerald-700"
            >
              Đăng nhập
            </Link>
          )}

          <button
            onClick={toggleTheme}
            aria-label="Đổi giao diện sáng/tối"
            className="rounded-lg border border-slate-300 px-3 py-1.5 hover:bg-slate-100 dark:border-slate-600 dark:hover:bg-slate-800"
          >
            {theme === "light" ? "🌙 Tối" : "☀️ Sáng"}
          </button>
        </nav>
      </div>
    </header>
  );
}
