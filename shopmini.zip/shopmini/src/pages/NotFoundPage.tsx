import { Link } from "react-router-dom";

export default function NotFoundPage() {
  return (
    <div className="py-20 text-center">
      <p className="text-6xl font-bold text-emerald-600 dark:text-emerald-400">404</p>
      <p className="my-4 text-lg text-slate-500">Trang bạn tìm không tồn tại.</p>
      <Link to="/" className="rounded-lg bg-emerald-600 px-5 py-2 font-medium text-white hover:bg-emerald-700">
        Về trang chủ
      </Link>
    </div>
  );
}
