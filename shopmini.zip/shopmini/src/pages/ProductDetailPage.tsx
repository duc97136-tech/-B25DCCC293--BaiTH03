import { useEffect } from "react";
import { Link, useParams } from "react-router-dom";
import { useAppDispatch, useAppSelector } from "../app/hooks";
import { fetchProducts } from "../features/products/productsSlice";
import { addToCart } from "../features/cart/cartSlice";
import { formatPrice } from "../utils/format";

export default function ProductDetailPage() {
  const { id } = useParams<{ id: string }>();
  const dispatch = useAppDispatch();
  const { items, status } = useAppSelector((s) => s.products);

  // Vào thẳng URL chi tiết (chưa qua trang chủ) thì vẫn cần tải dữ liệu
  useEffect(() => {
    if (status === "idle") {
      dispatch(fetchProducts());
    }
  }, [status, dispatch]);

  if (status === "idle" || status === "loading") {
    return <p className="py-10 text-center text-slate-500">Đang tải sản phẩm...</p>;
  }

  const product = items.find((p) => p.id === Number(id));

  if (!product) {
    return (
      <div className="py-10 text-center">
        <p className="mb-4 text-slate-500">Không tìm thấy sản phẩm.</p>
        <Link to="/" className="text-emerald-600 hover:underline dark:text-emerald-400">
          ← Về trang chủ
        </Link>
      </div>
    );
  }

  return (
    <div>
      <Link to="/" className="mb-4 inline-block text-emerald-600 hover:underline dark:text-emerald-400">
        ← Quay lại
      </Link>
      <div className="grid gap-8 rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-700 dark:bg-slate-800 md:grid-cols-2">
        <div className="flex items-center justify-center rounded-lg bg-white p-6">
          <img src={product.image} alt={product.title} className="max-h-96 object-contain" />
        </div>
        <div className="space-y-4">
          <span className="text-xs uppercase tracking-wide text-slate-500 dark:text-slate-400">
            {product.category}
          </span>
          <h1 className="text-2xl font-bold">{product.title}</h1>
          <p className="text-3xl font-bold text-emerald-600 dark:text-emerald-400">
            {formatPrice(product.price)}
          </p>
          <p className="text-slate-600 dark:text-slate-300">{product.description}</p>
          <button
            onClick={() => dispatch(addToCart(product))}
            className="rounded-lg bg-emerald-600 px-6 py-2.5 font-medium text-white hover:bg-emerald-700"
          >
            Thêm vào giỏ hàng
          </button>
        </div>
      </div>
    </div>
  );
}
