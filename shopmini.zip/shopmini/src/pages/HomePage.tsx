import { useEffect, useState } from "react";
import { useAppDispatch, useAppSelector } from "../app/hooks";
import { fetchProducts } from "../features/products/productsSlice";
import ProductCard from "../components/ProductCard";

export default function HomePage() {
  const dispatch = useAppDispatch();
  const { items, status, error } = useAppSelector((s) => s.products);
  // Từ khoá tìm kiếm chỉ dùng ở trang này -> để useState (local state)
  const [keyword, setKeyword] = useState("");

  useEffect(() => {
    if (status === "idle") {
      dispatch(fetchProducts());
    }
  }, [status, dispatch]);

  const filtered = items.filter((p) => p.title.toLowerCase().includes(keyword.trim().toLowerCase()));

  return (
    <section className="space-y-5">
      <input
        type="search"
        value={keyword}
        onChange={(e) => setKeyword(e.target.value)}
        placeholder="Tìm sản phẩm theo tên..."
        className="w-full rounded-lg border border-slate-300 bg-white px-4 py-2 outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 dark:border-slate-600 dark:bg-slate-800 dark:focus:ring-emerald-900"
      />

      {status === "loading" && <p className="py-10 text-center text-slate-500">Đang tải sản phẩm...</p>}

      {status === "failed" && (
        <div className="rounded-lg bg-red-50 p-4 text-center text-red-700 dark:bg-red-950 dark:text-red-300">
          <p>{error}</p>
          <button
            onClick={() => dispatch(fetchProducts())}
            className="mt-3 rounded-lg bg-red-600 px-4 py-1.5 text-white hover:bg-red-700"
          >
            Thử lại
          </button>
        </div>
      )}

      {status === "succeeded" && (
        <>
          {filtered.length === 0 ? (
            <p className="py-10 text-center text-slate-500">Không tìm thấy sản phẩm phù hợp.</p>
          ) : (
            <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-4">
              {filtered.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          )}
        </>
      )}
    </section>
  );
}
