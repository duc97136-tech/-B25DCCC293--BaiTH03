import { useState } from "react";
import { Link } from "react-router-dom";
import { useAppDispatch, useAppSelector } from "../app/hooks";
import { clearCart, selectCartItems, selectCartTotal } from "../features/cart/cartSlice";
import { formatPrice } from "../utils/format";

export default function CheckoutPage() {
  const dispatch = useAppDispatch();
  const items = useAppSelector(selectCartItems);
  const total = useAppSelector(selectCartTotal);
  // Cờ thông báo thành công chỉ dùng ở trang này -> useState
  const [ordered, setOrdered] = useState(false);

  if (ordered) {
    return (
      <div className="mx-auto max-w-md rounded-xl border border-green-300 bg-green-50 p-8 text-center dark:border-green-800 dark:bg-green-950">
        <p className="mb-2 text-4xl">✅</p>
        <h1 className="mb-2 text-2xl font-bold text-green-700 dark:text-green-300">Đặt hàng thành công!</h1>
        <p className="mb-5 text-slate-600 dark:text-slate-300">Cảm ơn bạn đã mua sắm tại ShopMini.</p>
        <Link to="/" className="rounded-lg bg-emerald-600 px-5 py-2 font-medium text-white hover:bg-emerald-700">
          Về trang chủ
        </Link>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="py-16 text-center">
        <p className="mb-4 text-lg text-slate-500">Không có sản phẩm nào để thanh toán.</p>
        <Link to="/" className="text-emerald-600 hover:underline dark:text-emerald-400">
          ← Về trang chủ
        </Link>
      </div>
    );
  }

  const handleOrder = () => {
    dispatch(clearCart());
    setOrdered(true);
  };

  return (
    <div className="mx-auto max-w-2xl space-y-5">
      <h1 className="text-2xl font-bold">Thanh toán</h1>
      <ul className="divide-y divide-slate-200 rounded-xl border border-slate-200 bg-white dark:divide-slate-700 dark:border-slate-700 dark:bg-slate-800">
        {items.map(({ product, quantity }) => (
          <li key={product.id} className="flex justify-between gap-4 p-4">
            <span className="line-clamp-1">
              {product.title} × {quantity}
            </span>
            <span className="font-medium">{formatPrice(product.price * quantity)}</span>
          </li>
        ))}
      </ul>
      <div className="flex items-center justify-between">
        <p className="text-lg">
          Tổng: <strong className="text-emerald-600 dark:text-emerald-400">{formatPrice(total)}</strong>
        </p>
        <button onClick={handleOrder} className="rounded-lg bg-emerald-600 px-6 py-2.5 font-medium text-white hover:bg-emerald-700">
          Đặt hàng
        </button>
      </div>
    </div>
  );
}
