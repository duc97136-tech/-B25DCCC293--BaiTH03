import { Link } from "react-router-dom";
import { useAppDispatch, useAppSelector } from "../app/hooks";
import {
  clearCart,
  removeFromCart,
  selectCartCount,
  selectCartItems,
  selectCartTotal,
  updateQuantity,
} from "../features/cart/cartSlice";
import { formatPrice } from "../utils/format";

export default function CartPage() {
  const dispatch = useAppDispatch();
  const items = useAppSelector(selectCartItems);
  const count = useAppSelector(selectCartCount);
  const total = useAppSelector(selectCartTotal);

  if (items.length === 0) {
    return (
      <div className="py-16 text-center">
        <p className="mb-4 text-lg text-slate-500">Giỏ hàng của bạn đang trống.</p>
        <Link to="/" className="rounded-lg bg-emerald-600 px-5 py-2 font-medium text-white hover:bg-emerald-700">
          Tiếp tục mua sắm
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Giỏ hàng ({count})</h1>
        <button onClick={() => dispatch(clearCart())} className="text-sm text-red-600 hover:underline">
          Xoá tất cả
        </button>
      </div>

      <ul className="divide-y divide-slate-200 rounded-xl border border-slate-200 bg-white dark:divide-slate-700 dark:border-slate-700 dark:bg-slate-800">
        {items.map(({ product, quantity }) => (
          <li key={product.id} className="flex flex-wrap items-center gap-4 p-4">
            <img src={product.image} alt={product.title} className="h-16 w-16 rounded bg-white object-contain" />
            <div className="min-w-0 flex-1">
              <p className="line-clamp-1 font-medium">{product.title}</p>
              <p className="text-sm text-slate-500 dark:text-slate-400">{formatPrice(product.price)}</p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => dispatch(updateQuantity({ id: product.id, quantity: quantity - 1 }))}
                className="h-8 w-8 rounded border border-slate-300 hover:bg-slate-100 dark:border-slate-600 dark:hover:bg-slate-700"
                aria-label="Giảm số lượng"
              >
                −
              </button>
              <span className="w-8 text-center">{quantity}</span>
              <button
                onClick={() => dispatch(updateQuantity({ id: product.id, quantity: quantity + 1 }))}
                className="h-8 w-8 rounded border border-slate-300 hover:bg-slate-100 dark:border-slate-600 dark:hover:bg-slate-700"
                aria-label="Tăng số lượng"
              >
                +
              </button>
            </div>

            <p className="w-24 text-right font-semibold">{formatPrice(product.price * quantity)}</p>
            <button
              onClick={() => dispatch(removeFromCart(product.id))}
              className="text-sm text-red-600 hover:underline"
            >
              Xoá
            </button>
          </li>
        ))}
      </ul>

      <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-700 dark:bg-slate-800">
        <p className="text-lg">
          Tổng cộng: <strong className="text-emerald-600 dark:text-emerald-400">{formatPrice(total)}</strong>
        </p>
        <Link to="/checkout" className="rounded-lg bg-emerald-600 px-6 py-2.5 font-medium text-white hover:bg-emerald-700">
          Thanh toán
        </Link>
      </div>
    </div>
  );
}
